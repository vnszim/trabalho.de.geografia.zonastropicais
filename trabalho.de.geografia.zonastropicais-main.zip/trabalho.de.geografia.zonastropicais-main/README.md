# trabalho.de.geografia.zonastropicais
🌍 Embarque na Missão GeoZonas! Analise diferentes ambientes da Terra e descubra se pertencem às zonas tropical, temperada ou polar, observando a temperatura média, a vegetação e as estações do ano. 🌡️🌿❄️ Explore e classifique o planeta — sua jornada geográfica começa agora!
